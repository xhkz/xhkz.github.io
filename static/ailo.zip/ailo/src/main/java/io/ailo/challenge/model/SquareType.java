package io.ailo.challenge.model;

public enum SquareType {
    ZOMBIE, CREATURE
}
