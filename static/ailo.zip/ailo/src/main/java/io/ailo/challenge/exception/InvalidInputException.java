package io.ailo.challenge.exception;

public class InvalidInputException extends IllegalArgumentException {
    public InvalidInputException(String s) {
        super(s);
    }
}
